use std::sync::Arc;

use shared::{
    State,
    extensions::{Extension, ExtensionRouteBuilder},
};

mod routes;
mod settings;

#[derive(Default)]
pub struct ExtensionStruct;

#[async_trait::async_trait]
impl Extension for ExtensionStruct {
    async fn initialize(&mut self, _state: State) {
        tracing::info!("dev_tomaxikz_subwaysurfersmeme extension initialized");
    }

    async fn initialize_router(
        &mut self,
        state: State,
        builder: ExtensionRouteBuilder,
    ) -> ExtensionRouteBuilder {
        builder
            .add_client_api_router(|routes| {
                routes.nest(
                    "/extensions/dev.tomaxikz.subwaysurfersmeme",
                    routes::client_router(&state),
                )
            })
            .add_admin_api_router(|routes| {
                routes.nest(
                    "/extensions/dev.tomaxikz.subwaysurfersmeme",
                    routes::admin_router(&state),
                )
            })
    }

    async fn settings_deserializer(
        &self,
        _state: State,
    ) -> shared::extensions::settings::ExtensionSettingsDeserializer {
        Arc::new(settings::ExtensionSettingsDataDeserializer)
    }
}
