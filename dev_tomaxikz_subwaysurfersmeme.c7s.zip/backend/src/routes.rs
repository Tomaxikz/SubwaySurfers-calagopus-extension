use shared::State;
use utoipa_axum::{router::OpenApiRouter, routes};

mod settings {
    use serde::{Deserialize, Serialize};
    use shared::{
        GetState,
        models::user::GetPermissionManager,
        response::{ApiResponse, ApiResponseResult},
    };
    use utoipa::ToSchema;

    #[derive(ToSchema, Serialize)]
    struct Response {
        enabled: bool,
    }

    #[derive(ToSchema, Deserialize)]
    pub struct Payload {
        enabled: bool,
    }

    #[utoipa::path(get, path = "/settings", responses(
        (status = OK, body = inline(Response)),
    ))]
    pub async fn get_route(state: GetState) -> ApiResponseResult {
        let settings = state.settings.get().await?;
        let extension_settings: &crate::settings::ExtensionSettingsData =
            settings.find_extension_settings()?;

        ApiResponse::new_serialized(Response {
            enabled: extension_settings.enabled,
        })
        .ok()
    }

    #[utoipa::path(put, path = "/settings", responses(
        (status = OK, body = inline(Response)),
    ), request_body = inline(Payload))]
    pub async fn put_route(
        state: GetState,
        permissions: GetPermissionManager,
        shared::Payload(data): shared::Payload<Payload>,
    ) -> ApiResponseResult {
        permissions.has_admin_permission("extensions.manage")?;

        let mut settings = state.settings.get_mut().await?;
        let extension_settings: &mut crate::settings::ExtensionSettingsData =
            settings.find_mut_extension_settings()?;

        extension_settings.enabled = data.enabled;
        let enabled = extension_settings.enabled;
        settings.save().await?;

        ApiResponse::new_serialized(Response { enabled }).ok()
    }
}

pub fn client_router(state: &State) -> OpenApiRouter<State> {
    OpenApiRouter::new()
        .routes(routes!(settings::get_route))
        .with_state(state.clone())
}

pub fn admin_router(state: &State) -> OpenApiRouter<State> {
    OpenApiRouter::new()
        .routes(routes!(settings::get_route, settings::put_route))
        .with_state(state.clone())
}
