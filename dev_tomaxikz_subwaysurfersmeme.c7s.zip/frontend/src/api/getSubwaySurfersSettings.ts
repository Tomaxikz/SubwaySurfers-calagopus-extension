import { axiosInstance } from '@/api/axios.ts';

export type SubwaySurfersSettings = {
  enabled: boolean;
};

export const subwaySurfersSettingsQueryKey = ['extensions', 'dev.tomaxikz.subwaysurfersmeme', 'settings'] as const;

export default async (): Promise<SubwaySurfersSettings> => {
  const { data } = await axiosInstance.get('/api/client/extensions/dev.tomaxikz.subwaysurfersmeme/settings');

  return data;
};
