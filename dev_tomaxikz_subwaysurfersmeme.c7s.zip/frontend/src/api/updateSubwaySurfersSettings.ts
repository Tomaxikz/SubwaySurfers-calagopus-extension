import { axiosInstance } from '@/api/axios.ts';
import { transformKeysToSnakeCase } from '@/lib/transformers.ts';
import type { SubwaySurfersSettings } from './getSubwaySurfersSettings.ts';

export default async (settings: SubwaySurfersSettings): Promise<SubwaySurfersSettings> => {
  const { data } = await axiosInstance.put(
    '/api/admin/extensions/dev.tomaxikz.subwaysurfersmeme/settings',
    transformKeysToSnakeCase(settings),
  );

  return data;
};
