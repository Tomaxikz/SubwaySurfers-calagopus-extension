import { useQuery } from '@tanstack/react-query';
import { useEffect, useRef } from 'react';
import { useWindows } from '@/providers/WindowProvider.tsx';
import getSubwaySurfersSettings, { subwaySurfersSettingsQueryKey } from '../api/getSubwaySurfersSettings.ts';
import { useExtTranslations } from '../translations.ts';

const VIDEO_ID = 'OYqBLPc01Dg';

export function SubwayBrainrotOverlay() {
  const { t: tExt } = useExtTranslations();
  const { addWindow, closeWindow } = useWindows();
  const windowId = useRef<number | null>(null);

  const { data, isError, isLoading } = useQuery({
    queryKey: subwaySurfersSettingsQueryKey,
    queryFn: getSubwaySurfersSettings,
  });

  useEffect(() => {
    if (isLoading || isError) {
      return;
    }

    if (data?.enabled === false) {
      if (windowId.current !== null) {
        closeWindow(windowId.current);
        windowId.current = null;
      }

      return;
    }

    if (data?.enabled === true && windowId.current === null) {
      const defaultWidth = window.innerWidth <= 760 ? 190 : 270;
      const defaultHeight = Math.min(window.innerHeight - 88, Math.round(defaultWidth * (16 / 9)) + 42);
      const id = addWindow(tExt('window.title', {}), <SubwayBrainrotWindowContent />, {
        defaultX: Math.max(8, window.innerWidth - defaultWidth - 24),
        defaultY: 72,
        defaultWidth,
        defaultHeight,
      });

      if (id !== -1) {
        windowId.current = id;
      }
    }
  }, [addWindow, closeWindow, data?.enabled, isError, isLoading, tExt]);

  useEffect(() => {
    return () => {
      if (windowId.current !== null) {
        closeWindow(windowId.current);
      }
    };
  }, [closeWindow]);

  return null;
}

function SubwayBrainrotWindowContent() {
  const params = new URLSearchParams({
    autoplay: '1',
    controls: '0',
    disablekb: '1',
    fs: '0',
    iv_load_policy: '3',
    loop: '1',
    modestbranding: '1',
    mute: '1',
    playsinline: '1',
    playlist: VIDEO_ID,
    rel: '0',
  });

  return (
    <div className='subway-brainrot-window'>
      <iframe
        allow='autoplay; encrypted-media; picture-in-picture'
        className='subway-brainrot-window__video'
        loading='eager'
        src={`https://www.youtube-nocookie.com/embed/${VIDEO_ID}?${params.toString()}`}
        title='Subway Surfers gameplay'
      />
    </div>
  );
}
