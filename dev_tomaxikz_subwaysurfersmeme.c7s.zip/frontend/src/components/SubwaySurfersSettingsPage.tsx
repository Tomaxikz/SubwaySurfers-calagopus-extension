import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { httpErrorToHuman } from '@/api/axios.ts';
import Button from '@/elements/Button.tsx';
import Card from '@/elements/Card.tsx';
import Switch from '@/elements/input/Switch.tsx';
import { useToast } from '@/providers/ToastProvider.tsx';
import getSubwaySurfersSettings, {
  type SubwaySurfersSettings,
  subwaySurfersSettingsQueryKey,
} from '../api/getSubwaySurfersSettings.ts';
import updateSubwaySurfersSettings from '../api/updateSubwaySurfersSettings.ts';
import { useExtTranslations } from '../translations.ts';

export function SubwaySurfersSettingsPage() {
  const { t: tExt } = useExtTranslations();
  const { addToast } = useToast();
  const queryClient = useQueryClient();
  const [enabled, setEnabled] = useState(true);

  const settingsQuery = useQuery({
    queryKey: subwaySurfersSettingsQueryKey,
    queryFn: getSubwaySurfersSettings,
  });

  useEffect(() => {
    if (settingsQuery.data) {
      setEnabled(settingsQuery.data.enabled);
    }
  }, [settingsQuery.data]);

  const updateMutation = useMutation({
    mutationFn: updateSubwaySurfersSettings,
    onSuccess: (settings: SubwaySurfersSettings) => {
      queryClient.setQueryData(subwaySurfersSettingsQueryKey, settings);
      setEnabled(settings.enabled);
      addToast(tExt('toast.saved', {}), 'success');
    },
    onError: (error) => addToast(httpErrorToHuman(error), 'error'),
  });

  const dirty = settingsQuery.data?.enabled !== enabled;
  const loading = settingsQuery.isLoading || updateMutation.isPending;

  return (
    <Card className='mt-4 max-w-xl'>
      <div className='flex flex-col gap-4'>
        <div>
          <h2 className='text-lg font-medium'>{tExt('pages.admin.settings.title', {})}</h2>
          <p className='mt-1 text-sm text-(--mantine-color-dimmed)'>{tExt('pages.admin.settings.description', {})}</p>
        </div>

        <Switch
          checked={enabled}
          description={tExt('pages.admin.settings.enabledDescription', {})}
          disabled={loading}
          label={tExt('pages.admin.settings.enabledLabel', {})}
          onChange={(event) => setEnabled(event.currentTarget.checked)}
        />

        <div className='flex justify-end'>
          <Button
            disabled={!dirty || loading}
            loading={updateMutation.isPending}
            onClick={() => updateMutation.mutate({ enabled })}
          >
            {tExt('button.save', {})}
          </Button>
        </div>
      </div>
    </Card>
  );
}
