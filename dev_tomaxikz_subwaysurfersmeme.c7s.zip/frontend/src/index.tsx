import type { MantineThemeOverride } from '@mantine/core';
import { Extension, type ExtensionContext } from 'shared';
import { SubwayBrainrotOverlay } from './components/SubwayBrainrotOverlay.tsx';
import { SubwaySurfersSettingsPage } from './components/SubwaySurfersSettingsPage.tsx';
import './app.css';

class DevTomaxikzSubwaySurfersMemeExtension extends Extension {
  public cardConfigurationPage: React.FC | null = SubwaySurfersSettingsPage;
  public cardComponent: React.FC | null = null;

  public initialize(ctx: ExtensionContext): void {
    ctx.extensionRegistry.global.appendComponent(SubwayBrainrotOverlay);
  }

  public initializeMantineTheme(_ctx: ExtensionContext): MantineThemeOverride {
    return {};
  }

  public processCall(ctx: ExtensionContext, _name: string, _args: object): unknown {
    return ctx.skip();
  }
}

export default new DevTomaxikzSubwaySurfersMemeExtension();
