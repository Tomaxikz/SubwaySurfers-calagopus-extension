import { defineTranslations } from 'shared';

const translations = defineTranslations({
  items: {},
  translations: {
    pages: {
      admin: {
        settings: {
          title: 'Subway Surfers Overlay',
          description: 'Control whether the gameplay window is shown in the panel.',
          enabledLabel: 'Enable overlay',
          enabledDescription: 'New installs are enabled by default. Turn this off to hide the video window everywhere.',
        },
      },
    },
    button: {
      save: 'Save',
    },
    toast: {
      saved: 'Settings saved.',
    },
    window: {
      title: 'Subway Surfers',
    },
  },
});

export const useExtTranslations = translations.useTranslations.bind(translations);
export const getExtTranslations = translations.getTranslations.bind(translations);

export default translations;
